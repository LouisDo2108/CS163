#pragma once
#ifndef _Header_H_
#define _Header_H_

int SumOfSquares(int n);

int GCD(int a, int b);

int FIB(int n);

#endif // !_Header_H_
