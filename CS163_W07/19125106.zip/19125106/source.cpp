#include "header.h"

NODE *CreateNode(int data)
{
    NODE *temp = new NODE;
    temp->key = data;
    temp->p_left = temp->p_right = nullptr;
    return temp;
}

void NLR(NODE *p_root)
{
    if (p_root)
    {
        cout << p_root->key << "->";
        NLR(p_root->p_left);
        NLR(p_root->p_right);
    }
}

void LNR(NODE *p_root)
{
    if (p_root)
    {
        LNR(p_root->p_left);
        cout << p_root->key << "->";
        LNR(p_root->p_right);
    }
}

void LRN(NODE *p_root)
{
    if (p_root)
    {
        LRN(p_root->p_left);
        LRN(p_root->p_right);
        cout << p_root->key << "->";
    }
}

void printLevel(NODE *p_root, int level)
{
    if (!p_root)
        return;
    if (level == 1)
        cout << p_root->key << "->";
    else if (level > 1)
    {
        printLevel(p_root->p_left, level - 1);
        printLevel(p_root->p_right, level - 1);
    }
}

void LevelOrder(NODE *p_root)
{
    int h = Height(p_root);
    for (int i = 0; i <= h; ++i)
        printLevel(p_root, i);
}

NODE *Search(NODE *p_root, int x)
{
    if (!p_root)
        return nullptr;
    if (x > p_root->key)
        Search(p_root->p_right, x);
    else if (x < p_root->key)
        Search(p_root->p_left, x);
    else
    {
        NODE *temp = p_root;
        return temp;
    }
}

void Insert(NODE *&p_root, int x)
{
    if (!p_root)
        p_root = CreateNode(x);
    else if (x > p_root->key)
        Insert(p_root->p_right, x);
    else if (x < p_root->key)
        Insert(p_root->p_left, x);
    else
        return;
}

void Remove(NODE *&p_root, int x)
{
    if (!p_root)
        return;
    else if (x > p_root->key)
        Remove(p_root->p_right, x);
    else if (x < p_root->key)
        Remove(p_root->p_left, x);
    else
    {
        NODE *del;
        if (!p_root->p_left && !p_root->p_right)
        {
            del = p_root;
            p_root = nullptr;
            delete p_root;
        }
        else if (!p_root->p_left && p_root->p_right)
        {
            del = p_root;
            p_root = p_root->p_right;
            delete del;
        }
        else if (!p_root->p_right && p_root->p_left)
        {
            del = p_root;
            p_root = p_root->p_left;
            delete del;
        }
        else
        {
            NODE *successor = p_root->p_right;
            while (successor && successor->p_left)
                successor = successor->p_left;
            p_root->key = successor->key;
            Remove(p_root->p_right, successor->key);
        }
    }
}

int Height(NODE *p_root)
{
    if (!p_root)
        return 0;
    return 1 + max(Height(p_root->p_left), Height(p_root->p_right));
}

int CountNode(NODE *p_root)
{
    if (!p_root)
        return 0;
    int count = 1;
    if (p_root->p_left)
        count += CountNode(p_root->p_left);
    if (p_root->p_right)
        count += CountNode(p_root->p_right);
    return count;
}

int Level(NODE *p_root, NODE *p);
int CountLeaf(NODE *p_root);
int CountLess(NODE *p_root, int x);
int CountGreater(NODE *p_root, int x);
bool IsBST(NODE *p_root);

void deleteTree(NODE *&p_root)
{
    if (p_root)
    {
        NODE *del;

        if (p_root->p_left)
        {
            deleteTree(p_root->p_left);
            del = p_root->p_left;
            delete del;
        }

        if (p_root->p_right)
        {
            deleteTree(p_root->p_right);
            del = p_root->p_right;
            delete del;
        }
    }
}