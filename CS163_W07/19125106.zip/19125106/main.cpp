#include "header.h"

int main()
{
    int choice, key;
    NODE *p_root = nullptr;

    while (1)
    {
        cout << "1. Create node" << endl;
        cout << "2. Pre-order Traversal" << endl;
        cout << "3. In-order Traversal" << endl;
        cout << "4. Post-order Traversal" << endl;
        cout << "5. Level-Order Traversal" << endl;
        cout << "6. Find and return a NODE with given value from a given Binary Tree" << endl;
        cout << "7. Add a NODE with given value into a given Binary Tree" << endl;
        cout << "8. Remove a NODE with given value from a given Binary Tree" << endl;
        cout << "9. Calculate the height of a given Binary Tree " << endl;
        cout << "10. Count the number of NODE from a given Binary Tree:" << endl;
        cout << "Please enter the choice or 0 to exit: ";
        cin >> choice;
        switch (choice)
        {
        case 1:
        {
            cout << "Enter the key: ";
            cin >> key;
            CreateNode(key);
            break;
        }
        case 2:
        {
            NLR(p_root);
            cout << endl;
            break;
        }
        case 3:
        {
            LNR(p_root);
            cout << endl;
            break;
        }
        case 4:
        {
            LRN(p_root);
            cout << endl;
            break;
        }
        case 5:
        {
            LevelOrder(p_root);
            cout << endl;
            break;
        }
        case 6:
        {
            cout << "Enter the key: ";
            cin >> key;
            NODE *temp = Search(p_root, key);
            if (temp)
                cout << "Found the node with the given value" << endl;
            else
                cout << "Can't find the node with the given value" << endl;
            break;
        }
        case 7:
        {
            cout << "Enter the key: ";
            cin >> key;
            Insert(p_root, key);
            break;
        }
        case 8:
        {
            cout << "Enter the key: ";
            cin >> key;
            Remove(p_root, key);
            break;
        }
        case 9:
        {
            cout << Height(p_root) << endl;
            break;
        }
        case 10:
        {
            cout << CountNode(p_root) << endl;
            break;
        }
        default:
        {
            deleteTree(p_root);
            return 0;
        }
        }
    }
}